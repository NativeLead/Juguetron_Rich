---
name: screens-ctv-biznaga
description: Monta screens de anuncios CTV (testigos de emisión) de Biznaga — la creatividad del cliente dentro del chrome del reproductor de 23 plataformas, en imagen o en MP4, y con la programación real de la librería de Drive pegada detrás. Úsalo cuando pidan un screen, un testigo, una captura de plataforma CTV o un MP4 anuncio+programación.
---

# Screens de anuncios CTV — Biznaga

Monta la creatividad de un cliente dentro de la interfaz real de una plataforma
de CTV y la entrega como **JPG/PNG** (testigo en imagen) o como **MP4** (el spot
corriendo, con contador y barra de progreso), y opcionalmente con **la
programación real de esa plataforma pegada detrás**, sacada de la librería de
Drive de la agencia.

```
[ anuncio con las plecas de la plataforma ]  corte seco  [ 20 s de programación limpia ]
```

## Lo primero que hay que entender

El aspecto de cada plataforma **vive en `platforms.json`, no en el código**.
Para calibrar una plataforma se edita su ficha; no se toca la lógica. Esa ficha
la consumen los dos motores, así que **lo que se ve en la vista previa es
idéntico a lo que se exporta**:

| Motor | Archivo | Para qué |
|---|---|---|
| Python (compositor) | `screens_ctv.py` | genera los JPG/PNG y los MP4 finales |
| Canvas (navegador) | `plantilla_script.js` | la plantilla HTML que usa Biznaga a mano |

Toda la geometría está en **% del ancho del lienzo** (`u = W/100 = 19.2` a
1920 px), así que la ficha vale igual a 1920, a 1280 o a 3840.

Hay tres tipos de ficha:

- **chrome sobre creatividad** (la mayoría): `bar`, `badge`, `ad`, `rem`,
  `icons`, `buttons`, `skip`, `labels`, `rings`.
- **`kind:"masthead"`**: la home del televisor (Samsung Tizen; `variant:"gtv"`
  para Sony y Philips con Google TV).
- **`kind:"page"`**: la pantalla completa descrita como lista de piezas —
  es lo que usa YouTube.

## Reglas estipuladas por Biznaga (no son opcionales)

Estas reglas nacieron de errores ya cometidos y corregidos. **No se
relajan, no se negocian y no vuelven a fallar.**

### 1. Nunca dibujar logos ni marcas de terceros

Ni logotipos, ni wordmarks, ni iconos de app de ninguna plataforma o
anunciante. Esos archivos **los aporta Biznaga** y entran por los slots
(`logo`, `plate`, `taskbar`, `cuenta`, `cuenta2`, `favicon`). Si falta un
asset, se pide; no se reconstruye a mano.

### 2. Alineación de la barra de progreso

La barra del MP4 tiene que caer **exactamente** sobre la pista que pinta la
plantilla. Dos trampas:

1. PIL pinta `d.rectangle` **incluyendo los dos filos**: un rectángulo de `y0`
   a `y0+bh` ocupa `bh+1` filas. El relleno del video se calcula con `bh+1` de
   alto y `x1-x0+1` de ancho.
2. El filtro `overlay` de ffmpeg trae **`format=yuv420` por defecto**, y en
   4:2:0 alinea la Y a filas **pares** y recorta las alturas impares. Hay que
   pasar `format=rgb` a **todos** los overlay de la barra. Sin eso, una barra
   en `y=903` de 15 px aterriza en 902 con 14 px.

Además el relleno se desliza **dentro de un lienzo transparente del tamaño
exacto de la barra**, para que no corra de canto a canto de la pantalla.

**Comprobación obligatoria** si se toca el montaje de la barra: medir en el MP4
las filas del relleno y de la pista y verificar que son las mismas.

### 3. Mismo volumen en el anuncio y en la programación

Los dos segmentos **siempre** acaban en el mismo nivel. Se mide la sonoridad de
ambos (EBU R128), se sube la programación con `loudnorm` de dos pasadas
(`linear=true`) y, si topa con el techo de −1 dBTP antes de llegar, **se baja el
anuncio** hasta ese mismo nivel. El corte no tiene salto.
`--sin-igualar-volumen` existe solo para diagnosticar, nunca para entregar.

### 4. El mismo creativo no repite programación

El nombre del creativo entra en el **registro de Drive**, así que el mismo spot
no vuelve a caer en una programación que ya usó — ni hoy, ni dentro de un mes,
ni aunque el contenedor sea otro. Ver [Registro](#registro-en-drive).

### 5. La tipografía de cada plataforma es la suya

Los textos de los formatos In-Home van en la tipografía de la plataforma, no en
una genérica: **One UI Sans** en Samsung Tizen y **Google Sans** en Google TV
(Sony y Philips). Las dos se piden por nombre y la de Google va incrustada,
porque Google la liberó en 2025. El detalle, las fuentes oficiales y lo que
**no** está documentado están en `reference/tipografia.md`.

### 6. Regla de contenido de YouTube

Ni el video anfitrión ni ninguno de los recomendados de la columna derecha
puede tratar de: **guerra o conflicto armado, política o elecciones, muerte o
luto, violencia o delito, catástrofes y accidentes, enfermedad grave, apuestas,
alcohol, tabaco o drogas, ni contenido sexual**. Tampoco se cuela ningún
anuncio ni promoción de un tercero. Si un título cae en cualquiera de esas
cestas se descarta y se pasa al siguiente; si no quedan suficientes aptos, se
completa con los **genéricos neutros** de la ficha antes que bajar el filtro.

## Cómo se usa

### Screens sueltos (imagen o MP4)

```bash
python3 screens_ctv.py spot.mp4 -p vix --frames 4 --outdir salida
python3 screens_ctv.py spot.mp4 -p vix --at 4.5 --lang en
python3 screens_ctv.py crea.jpg -p vix --secs 12 --progress 40
python3 screens_ctv.py spot.mp4 -p vix --mp4 -o screen.mp4
python3 screens_ctv.py --list
```

Idiomas: `--lang es | en | pt` (español, inglés, portugués de Brasil) en las 23
plataformas.

### Screen con programación detrás

```bash
python3 screen_programado.py spot.mp4 -p disney --pais "español latino"
python3 screen_programado.py spot.mp4 -p disney --pais LATAM --n 3
python3 screen_programado.py spot.mp4 -p netflix --pais LATAM \
    --categoria ROMANCE --prog-secs 20
```

Con `--n 3` salen tres MP4 y **cada uno cae en una categoría y un programa
distintos**. El creativo es, por defecto, el nombre del archivo del spot; se
fuerza con `--nombre-creativo`.

Opciones útiles: `--pais`, `--lang`, `--categoria`, `--titulo`, `--prog-secs`
(20 por defecto), `--outdir`, `--ad-i`, `--ad-n`, `--crf`, `--fields`, `--slot`,
`--semilla`, `--sin-red`, `--sin-igualar-volumen`.

### Librería de Drive

```bash
python3 libreria.py --meter indice_nuevo.json    # fusiona lo que trajo Claude
python3 libreria.py --listar --pais LATAM
python3 libreria.py --elegir --pais LATAM --plataforma disney --n 2
```

Estructura de la carpeta: `PAÍS / Plataforma / CATEGORÍA / clip.mp4`

- raíz: `1TB1H0SjFolc5wiBeWTl5CZEYYe6ot3ta`
- países: `LATAM`, `España`, `USA`, `IT`, `FRANCES`, `CATALAN`

El árbol **lo trae Claude con el conector de Drive** (el script no habla con la
API de Google) y queda en `libreria_index.json`. Los clips se bajan por
`uc?export=download&id=` con curl, que funciona porque la carpeta está
compartida por enlace.

Rotación: primero las categorías menos usadas; los títulos duplicados se
agrupan como un solo programa y se baja la copia más ligera; los títulos que ya
usó ese creativo quedan excluidos; si se agotan, avisa y reutiliza.

### Pantalla de YouTube

```bash
python3 gen_youtube.py                                  # regenera la ficha
python3 yt_canal.py --json canal.json --canal "Nombre" \
    --subs "8,55 K suscriptores" --url "youtube.com/watch?v=..."
python3 yt_canal.py --check "Elecciones 2026: el debate completo"
```

La pantalla **no se redibuja**: se usa una captura real como plancha
(`assets/youtube_plancha_biznaga.png`) y encima solo se repinta lo editable —
el hueco del reproductor, la tarjeta de patrocinio, la etiqueta
"Patrocinado · 1 de 1", el botón Saltar, la barra, los controles, el contador,
las dos fotos de cuenta y el reloj de la barra de tareas. El título, el canal,
los suscriptores y los recomendados salen de la captura.

Campos editables por video: `titulo`, `pestana`, `url`, `cardtexto`, `cardurl`,
`cta`, `hora`, `fecha`. Así **tres capturas del mismo canal pueden ser de tres
videos distintos** sin tocar la plancha.

### Plantilla HTML

```bash
python3 build_template.py     # -> plantilla_screens_ctv.html
```

Un solo archivo con todo embebido en base64. Se abre en el navegador, sin
instalar nada. Ver [reference/plantilla.md](reference/plantilla.md).

## Registro en Drive

El contenedor donde corre esto es efímero: cualquier caché local se pierde.
Para que el mismo creativo no repita programación, el histórico vive en Drive.

- carpeta: `1BNwBAS5VVa4kb4X_3pntPhutTNGsnF3f`
- sheet: `1_RQAQ6h9J2CzPpltBXgLVr-NRvSmoXkrBfGBVYaQVJg`
- lectura: `https://docs.google.com/spreadsheets/d/<sheet>/export?format=csv`

Columnas: `fecha, creativo, pais, plataforma, categoria, titulo, drive_id, nota`

**Por qué Sheet + CSV y no un solo archivo**: el conector de Drive puede
*crear* archivos, pero `update_file` solo cambia metadatos (título, carpeta),
**no el contenido**. Así que el registro se **lee** del Sheet y se **escribe**
como CSV nuevos y fechados que se van sumando (append-only). Las partes ya
subidas quedan listadas en `libreria_index.json` → `registro.partes`.

## Qué hay en el paquete

Todo va **en un solo nivel**, porque los scripts resuelven `platforms.json` y
`assets/` desde su propia carpeta. Si se reorganiza en subcarpetas, dejan de
encontrarse.

```
SKILL.md                     este archivo
reference/
  plantilla.md               la plantilla HTML: controles, slots, flujo
  fichas.md                  cómo se escribe y se calibra una ficha
  youtube.md                 la pantalla de YouTube en detalle
  libreria-drive.md          la librería, el registro y el estado de la indexación
  tipografia.md              qué fuente usa cada plataforma In-Home, con fuentes

screens_ctv.py               el compositor (imagen y MP4)
screen_programado.py         anuncio + programación, con el igualado de volumen
libreria.py                  la capa de Drive: índice, elección, registro
gen_youtube.py               genera la ficha "youtube"
yt_canal.py                  rellena los recomendados y aplica el filtro de contenido
samsung_tizen.py             genera la ficha masthead de Samsung
gtv_home.py                  genera la ficha masthead de Google TV
build_template.py            empaqueta la plantilla HTML

platforms.json               las 23 fichas — la fuente de verdad
libreria_index.json          el árbol de Drive indexado + los IDs del registro

plantilla_screens_ctv.html   la plantilla lista para abrir con doble clic
plantilla_body.html          el cuerpo sin empaquetar
plantilla_script.js          el motor de canvas
style.css

assets/                      planchas y piezas que aportó Biznaga
  youtube_plancha_biznaga.png  la plancha aprobada de YouTube
  youtube_page.jpg             plancha de respaldo
  taskbar_w11.png              la tira limpia de la barra de tareas
  avatar_generico.png          el icono de usuario que sustituye las fotos
  samsung_home.jpg             la home de Samsung Tizen
  gtv_home.jpg                 la home de Google TV
  logo_placeholder.png         disco gris neutro, para cuando falta el logo
  yt_anunciante.png            pieza de la tarjeta de patrocinio
  pluto_wordmark_blanco.png    aportado por Biznaga
  googlesansflex_latin.woff2       Google Sans (código abierto, 2025) — la
  googlesansflex_latin_ext.woff2   tipografía de Google TV, incrustada
```

## Cómo se instala

El `.skill` es un **zip**: se descomprime y la carpeta `screens-ctv-biznaga/`
entera se deja en el directorio de skills de Claude (`~/.claude/skills/` en
Mac y Linux, `%USERPROFILE%\.claude\skills\` en Windows). Al arrancar, Claude
la reconoce por el `SKILL.md` y la usa cuando pidan un screen o un testigo.

Dos cosas que conviene tener claras:

- **La plantilla HTML no necesita nada de esto.** `plantilla_screens_ctv.html`
  es autónoma: se puede pasar por correo a cualquiera del equipo y funciona con
  doble clic, sin Python, sin ffmpeg y sin la skill instalada.
- **Los scripts sí.** Necesitan Python, Pillow, numpy y ffmpeg en la máquina
  donde corran, y los archivos tienen que estar juntos en la misma carpeta.

## Requisitos

- Python 3 con **Pillow** y **numpy**
- **ffmpeg** y **ffprobe** en el PATH
- fuentes: Liberation, FreeSans, DejaVu, Carlito, Poppins (cada ficha elige la
  que más se parece a la suya)
- la plantilla HTML no depende de las fuentes del equipo: lleva **Google Sans
  Flex** incrustada (54 KB), que es la tipografía real de Google TV y el
  suplente de One UI Sans en Samsung — ver `reference/tipografia.md`
- para la librería: `curl` y la carpeta de Drive compartida por enlace

## Estado y pendientes

- **23 plataformas** en la ficha, las tres lenguas (`es`/`en`/`pt`) en todas.
- LATAM indexado: Disney (10 categorías / 45 clips), Netflix (21, sin
  categorías), ViX (5/14), HBO (3/35, mezclado), Pluto (9, sin categorías),
  Prime (2). **Quedan 14 plataformas LATAM sin indexar** (2 llamadas de Drive
  cada una).
- El permiso de la carpeta de la librería está en *"cualquiera con el enlace
  puede editar"* — conviene bajarlo a **lector**.
- Hay **títulos duplicados** en ViX, HBO, Pluto y Netflix; el código los
  agrupa, pero conviene limpiarlos en Drive.
- El clip *El Juez* de HBO está masterizado a **−42,5 LUFS** (30 dB por
  debajo): igualarlo amplifica su piso de ruido. Conviene reexportarlo.
- Prime Video tiene solo **2 programas**.
- Netflix no tiene subcarpetas de categoría en Drive.
- Los masters de MADRID BEATS LATAM vienen **con barras laterales**
  (contenido de 1556×1079 dentro de 1920×1080).
- El portugués está escrito por criterio, **sin verificar contra capturas
  reales de Brasil** — igual que el español de Prime, Hulu, Disney, ESPN y
  Univisión.
